#1 follow the install instructions to install node...

https://tiddlywiki.com/static/Installing%2520TiddlyWiki%2520on%2520Node.js.html

#2 create a folder I used TiddlyWikiNodeProjects as my projects folder, use what you want.

TiddlyWikiNodeProjects

#3 unzip the TiddlyWikiNodeExperiment.zip in the projects folder
you should have a folder TiddlyWikiNodeExperiment with the project contents folder and a copy of this readme, yes it is a bit confusing just trust me.

TiddlyWikiNodeExperiment
--TWNodeExperiment
--readme to get started.txt

#4 open the TiddlyWikiNodeExperiment folder in a terminal and issue the command...

tiddlywiki TWNodeExperiment --listen

#5 you should see something like this...

{user}@{computer}:/TiddlyWikiNodeProjects/TiddlyWikiNodeExperiment$ tiddlywiki TWNodeExperiment --listen
syncer-server-filesystem: Dispatching 'save' task: $:/StoryList
Serving on http://127.0.0.1:8080
(press ctrl-C to exit)


#6 To save the TW out of node...

--In the terminal window exit out of the server and...

tiddlywiki TWNodeExperiment --build index

--Or... just save from the browser

right-click "Save Page As..." or ctl-s

#7 When your done here go look at the folder structure of the TWNodeExperiment folder.
You will find in the plugins folder a example plugin I made.
In the tiddlers folder you will find regular tiddlers
as well as tiddlers overwriting shadow tiddlers.

[folder] TWNodeExperiment
– [folder] languages
– [folder added by build later on] output
– [folder] plugins
– – [folder] get-tagged-tiddlers
– – – [folder] macros
– – – – [file] getTaggedTiddlers.tid
– – – [file] plugin.info
– – – [folder] tiddlers
– – – – [file] readme.tid
– [folder] themes
– [folder] tiddlers
– – – [files] any regular tiddlers you have made and any that overwrite system, etc. – [file] tiddlywiki.info

#8 honestly I use tinka but I wnted to know how node worked, just in case, so I did not make it much further than this.

-Think I extracted a plugin and dropped a plugin in just to see how that worked.
https://www.reddit.com/r/TiddlyWiki5/comments/mwlpee/how_to_export_a_plugin_from_a_wiki_and_make_it/

Went and got the tinka source and dropped it in as a plugin, again just to see how it was done.
https://www.reddit.com/r/TiddlyWiki5/comments/mwlpee/how_to_export_a_plugin_from_a_wiki_and_make_it/

#9 there is a more advanced way of using node to develop tw.. but have not tried it

https://tiddlywiki.com/dev/static/Developing%2520plugins%2520using%2520Node.js%2520and%2520GitHub.html

#10

good luck
-frakier
